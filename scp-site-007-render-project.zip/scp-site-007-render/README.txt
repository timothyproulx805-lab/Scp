SCP SITE 007 - RENDER-READY NODE PROJECT

FILES
- package.json: tells Render how to install and start the server
- server.js: account sign-in/sign-up and shared group-chat server
- public/index.html: the existing SCP Site 007 interface

RENDER SETTINGS
1. Create a Web Service from this GitHub repository.
2. Runtime: Node (NOT Docker).
3. Build command: npm install
4. Start command: npm start
5. Choose the Free instance if offered.

IMPORTANT
- The app is served by the same server, so leave the Server Address field blank when using this deployed site.
- Every person must open the same Render website address and create their own account there.
- This starter stores accounts and messages in a local JSON file. Render's free service filesystem can reset on redeploy/restart, so messages/accounts are not guaranteed permanent. A persistent database is needed for reliable long-term storage.
- This is a fictional roleplay interface, not a real security/access-control system.
- Group chat is implemented. Card scanning and JOCK AI are not connected in this starter; those endpoints return a clear unavailable message rather than pretending to verify cards or run AI.
- Before making a public production service, set a strong SESSION_SECRET environment variable and add persistent database storage, rate limiting, and other protections.
