const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'site007.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], messages: [] }, null, 2));
function readDB() { try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { return { users: [], messages: [] }; } }
function writeDB(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
app.set('trust proxy', 1);
app.use(express.json({ limit: '2mb' }));
app.use(session({
  name: 'site007.sid',
  secret: process.env.SESSION_SECRET || 'change-this-session-secret-before-public-launch',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, 'public')));

const clean = v => String(v || '').trim();
function publicUser(u) { return { id: u.id, username: u.username, displayName: u.displayName }; }
function requireUser(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Please sign in first.' });
  const user = readDB().users.find(u => u.id === req.session.userId);
  if (!user) { req.session.destroy(() => {}); return res.status(401).json({ error: 'Please sign in again.' }); }
  req.user = user; next();
}
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'SCP Site 007', chat: true }));
app.get('/api/auth/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = readDB().users.find(u => u.id === req.session.userId);
  res.json({ user: user ? publicUser(user) : null });
});
app.post('/api/auth/signup', async (req, res) => {
  const displayName = clean(req.body.displayName).slice(0, 32);
  const username = clean(req.body.username).toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 20);
  const password = String(req.body.password || '');
  if (displayName.length < 2 || username.length < 3 || password.length < 8) return res.status(400).json({ error: 'Use a display name (2+ characters), username (3+ letters/numbers/_), and password (8+ characters).' });
  const db = readDB();
  if (db.users.some(u => u.username === username)) return res.status(409).json({ error: 'That username is already taken.' });
  const user = { id: require('crypto').randomUUID(), displayName, username, passwordHash: await bcrypt.hash(password, 12), createdAt: new Date().toISOString() };
  db.users.push(user); writeDB(db); req.session.userId = user.id;
  res.json({ user: publicUser(user) });
});
app.post('/api/auth/signin', async (req, res) => {
  const username = clean(req.body.username).toLowerCase();
  const password = String(req.body.password || '');
  const user = readDB().users.find(u => u.username === username);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: 'Username or password is incorrect.' });
  req.session.userId = user.id; res.json({ user: publicUser(user) });
});
app.post('/api/auth/signout', (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/group/messages', requireUser, (req, res) => {
  const db = readDB();
  res.json({ messages: db.messages.slice(-150) });
});
app.post('/api/group/messages', requireUser, (req, res) => {
  const text = clean(req.body.text);
  if (!text || text.length > 2000) return res.status(400).json({ error: 'Message must be between 1 and 2000 characters.' });
  const db = readDB();
  const message = { id: require('crypto').randomUUID(), username: req.user.username, displayName: req.user.displayName, text, createdAt: new Date().toISOString() };
  db.messages.push(message); db.messages = db.messages.slice(-1000); writeDB(db);
  res.json({ message });
});
// The front-end has optional scanner and JOCK chat panels. These safe responses keep
// the app's chat working without pretending an AI key or card-verification service exists.
app.post('/api/scan', requireUser, (_req, res) => res.status(503).json({ error: 'Card scanning is not connected to a verification service on this server yet.' }));
app.post('/api/chat', requireUser, (_req, res) => res.status(503).json({ error: 'JOCK AI is not configured on this server yet.' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`SCP Site 007 running on port ${PORT}`));
